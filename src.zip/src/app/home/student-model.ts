export class Student
{
    public constructor(public stu_id:number,public stu_email_id:string,public pass:string,
    public f_name:string,public m_name:string,public l_name:string,public gen:string,
    public addhar_no:number,public address:string,public m_no:number,public qualification:string,public img:string,
    public dob:Date,public flag:number,public fk_course_id:number ){

    }
}
export class Studentcourse
{
    public constructor(public stu_id:number,public stu_email_id:string,public pass:string,
    public f_name:string,public m_name:string,public l_name:string,public gen:string,
    public addhar_no:number,public address:string,public m_no:number,public qualification:string,public img:string,
    public dob:Date,public flag:number,public fk_course_id:number,public course_id:number,public course_title:string,public course_desc:string,public course_duration:string,public course_fees:number ){

    }
}
export class updatestu
{
    public constructor(public stu_id:number,public stu_email_id:string,
    public f_name:string,public m_name:string,public l_name:string,public gen:string,
    public addhar_no:number,public address:string,public m_no:number,public qualification:string,public img:string,
    public dob:Date,public flag:number,public fk_course_id:number ){

    }
}
