export class Gallary{
    public constructor(public pic_id:number,public pic_title:string,public pic_img:string){

    }
}