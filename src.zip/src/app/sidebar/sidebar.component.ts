import { Component, OnInit } from '@angular/core';
import { LoginDataService } from '../login/login-data.service';
import { Login } from '../login/login-model';
import { Router,ActivatedRoute } from '@angular/router';
import{ Subscription} from 'rxjs/Rx';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  _Subscription:Subscription;
  public pass:string;
  public oldpass:string;
  public newpass:string;
  constructor(public _data:LoginDataService,public _r:Router,public _activerouter:ActivatedRoute) { }
email_id=localStorage.getItem('Email');
  ngOnInit() {
    this.email_id=localStorage.getItem('Email');
    this._data.getadmintById(this.email_id).subscribe(
      (data:Login[])=>{
        this.pass=data[0].pass;       
      }
    );
    
   
  }
  logout()
  {
    this._r.navigate(["/login"]);
  }
  onupdate()
    {    
      if(this.oldpass==this.pass)
      {
        let item=new Login(null,this.pass);
        if(this.newpass==null)
        {alert("enter new password");}
        else{
          this._data.updatepass(this.email_id,item).subscribe(
            (data:any)=>{
            console.log(data);            
             alert("password change suceessfull");
            }
          );
        }
        

      }
      else{
        alert("your old password is not correct");
      }
       
      }

}
