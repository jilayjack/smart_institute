import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import { UserDataService } from './admin-data.service';
import { Event } from './events-model';
import { Router } from '@angular/router';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-event',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit, AfterViewInit {
public events:Event[]=[];
public events1:Event[]=[];
public delarr:Event[]=[];
public evedate:Event[]=[];
datedb:number;
datesys:number;
monthdb:number;
monthsys:number;
yeardb:number;
yearsys:number;
sysdate:Date=new Date(Date.now());
dataSource: MatTableDataSource<Event>;
displayedColumns = [' ','event_title', 'event_desc','event_location','event_img','event_date','event_time','seminar_video','course_title','Action'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

constructor(public _data:UserDataService,public _r:Router) { }

  ngOnInit() {
    
    this._data.geteventcourse().subscribe(
      (data:any)=>{
        this.events=data;
        this.events1=data;
        this.dataSource = new MatTableDataSource<Event>(this.events);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      
        for(this.i=0 ; this.i<this.events.length ; this.i++)
          {
            this.datedb=new Date(data[this.i].event_date).getDate();
            this.datesys=this.sysdate.getDate();
            this.monthdb=new Date(data[this.i].event_date).getMonth();
            this.monthsys=this.sysdate.getMonth();
            this.yeardb=new Date(data[this.i].event_date).getFullYear();
            this.yearsys=this.sysdate.getFullYear();
             if(this.datedb == this.datesys && this.monthdb==this.monthsys &&this.yeardb==this.yearsys)
            {
              //console.log("event on date"+data[this.i].event_title);
            }
            else if(new Date(data[this.i].event_date) < this.sysdate)
            {
              //console.log("event puri"+data[this.i].event_title);
             //console.log(data[this.i]);
             this.evedate.push(data[this.i]);
              console.log(this.evedate);
            }
            else{
             // console.log("event baki"+data[this.i].event_title);
            }
          }
           }
    );
   
  }
  ngAfterViewInit(){

  }
  deletecomplete()
  {
    if(confirm("Are You Sure want to delete all past event?"))
    {
    this._data.delteAllevents(this.evedate).subscribe(      
        (data:any)=>{          
          for(this.i=0 ; this.i<this.evedate.length ; this.i++)
          {    
            this.dataSource.data.splice( this.dataSource.data.indexOf(this.evedate[this.i]),1);
                console.log("Complete"); 
                this.dataSource.paginator=this.paginator;          
          }
          this.evedate=[];          
        },
        function(err){console.log(err);},
        function(){
        }      
    );
  }
  }
  search(item)
  {
    if(item!=''){
    this.events=this.events1.filter((x)=>x.event_title.indexOf(item)!==-1)
    }
    else{
      this.events=this.events1
    }
  }
oneventDelete(item){
  if(confirm("Are You Sure want to delete?"))
  {
    this._data.deleteUser(item.event_id).subscribe(
      (data:any)=>{
        this.dataSource.data.splice( this.dataSource.data.indexOf(item),1);
        this.dataSource.paginator=this.paginator;
          }
    );
  }
}
  
  
  onupdatec(item)
  {
    this._r.navigate(["/update-event",item.event_id]);
  }
  i:number=0;
  checkChange(item)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
      
  }

  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllevents(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

            this.dataSource.data.splice( this.dataSource.data.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;
              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }

  
  }

