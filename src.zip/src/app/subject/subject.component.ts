import { Component, OnInit,ViewChild, AfterViewInit} from '@angular/core';
import { SubjectDataService } from './subject-data.service';
import { Subject } from './subject-model';
import { Router } from '@angular/router';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.css']
})
export class SubjectComponent implements OnInit, AfterViewInit {
  displayedColumns = [' ','sub_title', 'sub_desc','course_title','faculty_name','Action'];
  public subject:Subject[]=[];
public subject1:Subject[]=[];
public delarr:Subject[]=[];
dataSource: MatTableDataSource<Subject>;
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator:MatPaginator;

constructor(public _data:SubjectDataService,public _r:Router) { }

  ngOnInit() {
    this._data.getAllSubject().subscribe(
      (data:any)=>{
        this.subject=data;
        this.subject1=data;
        this.dataSource = new MatTableDataSource<Subject>(data);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      }
    );
  }
  ngAfterViewInit(){
   // this.dataSource=new MatTableDataSource<Subject>(this.subject);
  
      }
  search(item)
  {
    if(item!=''){
    this.subject=this.subject1.filter((x)=>x.sub_title.indexOf(item)!==-1)
    }
    else{
      this.subject=this.subject1
    }
  }
  onsubDelete(item){
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.deleteSubject(item.sub_id).subscribe(
      (data:any)=>{
        //this.subject.splice(this.subject.indexOf(item),1);
        this.dataSource.data.splice(this.dataSource.data.indexOf(item),1);
        this.dataSource.paginator=this.paginator;
      }
    );
  }
}
  onupdate(item)
  {
    this._r.navigate(["/update-subject",item.sub_id]);
  }
  i:number=0;
  checkChange(item:Subject)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
    
  }
  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllsubject(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

                this.subject.splice(this.subject.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;

              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }
}
