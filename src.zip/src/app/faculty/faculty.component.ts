import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import { Faculty } from './faculty-model';
import { FacultyDataService } from './faculty-data.service';
import { Router } from '@angular/router';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})
export class FacultyComponent implements OnInit {
  public faculty:Faculty[]=[];
  public  faculty1:Faculty[]=[];
  public delarr: Faculty[]=[];
  dataSource: MatTableDataSource<Faculty>;
displayedColumns = [' ','f_email_id', 'faculty_name','f_address','f_m_no','f_qalification','f_experience','f_join_date','f_img','Action'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public _data:FacultyDataService,public _r:Router) { }

    ngOnInit() {
    this._data.getAllFaculty().subscribe(
          (data:any)=>{
            this.faculty=data;
            this.faculty1=data;
            this.dataSource = new MatTableDataSource<Faculty>(this.faculty);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
          }
        );
      }
      search(item)
      {
        if(item!=''){
        this.faculty=this.faculty1.filter((x)=>x.faculty_name.indexOf(item)!==-1)
        }
        else{
          this.faculty=this.faculty1
        }
      }
    
      onFacultyDelete(item){
        if(confirm("Are You Sure want to delete?"))
        {
        this._data.deleteFaculty(item.faculty_id).subscribe(
          (data:any)=>{
            this.dataSource.data.splice( this.dataSource.data.indexOf(item),1);
            this.dataSource.paginator=this.paginator;
          }
        );
      }
    }
      onupdatec(item)
      {
        this._r.navigate(["/update-faculty",item.faculty_id]);
      }
      
      i:number=0;
      checkChange(item:Faculty)
      {
        
          if(this.delarr.find(x=>x==item))
          {
            this.delarr.splice(this.delarr.indexOf(item),1);
          }
          else
          {
            this.delarr.push(item);
          }
          console.log(this.delarr);
        
      }
      deleteAll()
      {
        
        if(confirm("Are You Sure want to delete?"))
        {
        this._data.delteAllFaculty(this.delarr).subscribe(
          
            (data:any)=>{
              
              for(this.i=0 ; this.i<this.delarr.length ; this.i++)
              {
                 
    
                this.dataSource.data.splice( this.dataSource.data.indexOf(this.delarr[this.i]),1);
                    console.log("Complete");
                    this.dataSource.paginator=this.paginator;
                  
              }
              this.delarr=[];
              
            },
            function(err){console.log(err);},
            function(){
    
            }
          
        );
      }
      }
    }
