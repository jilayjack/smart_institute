export class Faculty
{
    public constructor(public faculty_id:number,public f_email_id:string,public f_pass:string,
    public faculty_name:string,public f_address:string,public f_m_no:string,public f_qalification:string,
    public f_experience:string,public f_join_date :string,public f_img:string){

    }
}
export class Facultyadmin
{
    public constructor(public faculty_id:number,public f_email_id:string,
    public faculty_name:string,public f_address:string,public f_m_no:string,public f_qalification:string,
    public f_experience:string,public f_join_date :string,public f_img:string){

    }
}