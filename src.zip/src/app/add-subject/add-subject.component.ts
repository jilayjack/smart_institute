import { Component, OnInit } from '@angular/core';
import { SubjectDataService } from '../subject/subject-data.service';
import { Subject } from '../subject/subject-model';
import { Router } from '@angular/router';
import { Course } from '../course/course-model';
import { CourseDataService } from '../course/course-data.service';
import { Faculty } from '../faculty/faculty-model';
import { FacultyDataService } from '../faculty/faculty-data.service';

@Component({
  selector: 'app-add-subject',
  templateUrl: './add-subject.component.html',
  styleUrls: ['./add-subject.component.css']
})
export class AddSubjectComponent implements OnInit {
  public course:Course[]=[];
  public faculty:Faculty[]=[];
  title:string='';
desc:string='';
course_id:string;
faculty_id:string;
f_id:number;
c_id:number;

  
  constructor(public _data:SubjectDataService,public _r:Router,public _cs:CourseDataService,public _fs:FacultyDataService) { }

  ngOnInit() {
    this._cs.getAllCourses().subscribe(
      (data:any)=>{
        this.course=data;
        console.log(data);
      }
    );
    this._fs.getAllFaculty().subscribe(
      (data:any)=>{
        this.faculty=data;
        console.log(data);
      }
    );
   

  }
add()
{
  
  this.c_id=parseInt(this.course_id);
  this.f_id=parseInt(this.faculty_id);
  console.log("course id"+this.c_id);
 

  this._data.addSubject(new Subject(null,this.title,this.desc,this.f_id,this.c_id)).subscribe(
        (data:any)=>{
        console.log(data);
        
         // alert('Add Successfull');
          this._r.navigate(["/subject"]);
        }
      );

}
}
