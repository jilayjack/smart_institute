import { Injectable } from '@angular/core';
import { Report } from '../report/report_model';
import { HttpClient,HttpHeaders } from '@angular/common/http';
@Injectable()
export class ReportDataService {
  public urlrf:string="http://localhost:3000/report_faculty/";
  public url:string="http://localhost:3000/report/";
  public urldel:string="http://localhost:3000/delallreport/";
  content:string="Content-Type";
value:string="application/json";

  constructor(public _http:HttpClient) { }
  getAllreport(){
    return this._http.get<Report>(this.urlrf);
  }
  deletereport(id:string){
    return this._http.delete(this.url+id,{headers:new HttpHeaders().set('Content-Type','application/json')});
  }
  delteAllreport(stu:Report[]){
    let body=JSON.stringify(stu);
    return this._http.post(this.urldel,body,{headers:new HttpHeaders().set(this.content,this.value)});
  }

}
