export class Report
{
    public constructor(public report_id:number,public report_title:string,public report_desc:string,
    public date:Date,public fk_faculty_id:number){

    }
}
