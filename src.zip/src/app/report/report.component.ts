import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import {Report } from './report_model';
import { ReportDataService } from './report-data.service';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit, AfterViewInit {
  public report:Report[]=[];
  public report1:Report[]=[];
  public delarr:Report[]=[];
  dataSource: MatTableDataSource<Report>;
displayedColumns = [' ','report_title', 'report_desc','date','faculty_name','f_email_id','Action'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public _data:ReportDataService) { }

  ngOnInit() {
    this._data.getAllreport().subscribe(
      (data:any)=>{
        this.report=data;
        this.report1=data;
        this.dataSource = new MatTableDataSource<Report>(this.report);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
        console.log(this.report);
      }
    );
    
  }
  ngAfterViewInit(){

  }

  search(item)
  {
    if(item!=''){
    this.report=this.report1.filter((x)=>x.report_title.indexOf(item)!==-1)
    }
    else{
      this.report=this.report1
    }
  }
onreportDelete(item){
  if(confirm("Are You Sure want to delete?"))
  {
    this._data.deletereport(item.report_id).subscribe(
      (data:any)=>{
        this.dataSource.data.splice(this.report.indexOf(item),1);
        this.dataSource.paginator=this.paginator;
      }
    );
  }
}
  i:number=0;
  checkChange(item:Report)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
    
  }
  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllreport(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

            this.dataSource.data.splice(this.report.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;
              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }


}
