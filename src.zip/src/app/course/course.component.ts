import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import { Course } from './course-model';
import { CourseDataService } from './course-data.service';
import { Router } from '@angular/router';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
public course:Course[]=[];
public course1:Course[]=[];
public delarr:Course[]=[];
dataSource: MatTableDataSource<Course>;
displayedColumns = [' ','course_title', 'course_desc','course_duration','course_fees','course_img','Action'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

constructor(public _data:CourseDataService,public _r:Router) { }

  ngOnInit() {
this._data.getAllCourses().subscribe(
      (data:any)=>{
        this.course=data;
        this.course1=data;
        this.dataSource = new MatTableDataSource<Course>(this.course);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      }
    );
  }
  search(item)
  {
    if(item!=''){
    this.course=this.course1.filter((x)=>x.course_title.indexOf(item)!==-1)
    }
    else{
      this.course=this.course1
    }
  }

  oncoursetDelete(item){
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.deleteCourse(item.course_id).subscribe(
      (data:any)=>{
        this.dataSource.data.splice( this.dataSource.data.indexOf(item),1);
        this.dataSource.paginator=this.paginator;
      }
    );
  }
}
  onupdatec(item)
  {
    this._r.navigate(["/update-course",item.course_id]);
  }
  
  i:number=0;
  checkChange(item:Course)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
    
  }
  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllCourse(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

            this.dataSource.data.splice( this.dataSource.data.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;
              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }
}


