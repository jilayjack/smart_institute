export class Course{
    public constructor(public course_id:number,public course_title:string,public course_desc:string,public course_duration:number,public course_fees:number,public course_img:string){
        
    }
}