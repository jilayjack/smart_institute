import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import { Feedback } from './feedback-model';
import { FeedbackDataService } from './feedback-data.service';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit, AfterViewInit {
  public feedback:Feedback[]=[];
  public feedback1:Feedback[]=[];
  public delarr:Feedback[]=[];
  constructor(public _data:FeedbackDataService) { }
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator:MatPaginator;
  displayedColumns = [' ','feedback_title', 'feedback_desc','date','f_name','stu_email_id','Action'];
  dataSource: MatTableDataSource<Feedback>;
  ngOnInit() {
    this._data.getAllfeedback().subscribe(
      (data:any)=>{
        this.feedback=data;
        this.feedback1=data;
        this.dataSource=new MatTableDataSource<Feedback>(this.feedback);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      }
    );
  }
  ngAfterViewInit(){
    // this.dataSource=new MatTableDataSource<Subject>(this.subject);
   
       }
  
  
  search(item)
  {
    if(item!=''){
    this.feedback=this.feedback1.filter((x)=>x.feedback_title.indexOf(item)!==-1)
    }
    else{
      this.feedback=this.feedback1
    }
  }
onfeedbacktDelete(item){
  if(confirm("Are You Sure want to delete?"))
  {
    this._data.deletefeedback(item.feedback_id).subscribe(
      (data:any)=>{
        this.feedback.splice(this.feedback.indexOf(item),1);
         this.dataSource.paginator=this.paginator;
      }
    );
  }
}
  i:number=0;
  checkChange(item:Feedback)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
    
  }
  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllfeedback(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

                this.feedback.splice(this.feedback.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;

              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }


}
