export class Feedback
{
    public constructor(public feedback_id:number,public feedback_title:string,public feedback_desc:string,
    public date:Date,public fk_student_id:number){

    }
}
