import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Feedback } from './feedback-model';
@Injectable()
export class FeedbackDataService {
  public urlfs:string="http://localhost:3000/feedback_stu/";
  public url:string="http://localhost:3000/feedback/";
  public urldel:string="http://localhost:3000/delallfeedback/";
  content:string="Content-Type";
value:string="application/json";

  constructor(public _http:HttpClient) { }
  getAllfeedback(){
    return this._http.get<Feedback>(this.urlfs);
  }
  deletefeedback(id:string){
    return this._http.delete(this.url+id,{headers:new HttpHeaders().set('Content-Type','application/json')});
  }
  delteAllfeedback(stu:Feedback[]){
    let body=JSON.stringify(stu);
    return this._http.post(this.urldel,body,{headers:new HttpHeaders().set(this.content,this.value)});
  }

}
