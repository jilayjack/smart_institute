export class News{
    public constructor(public news_id:number,public news_title:string,public new_desc:string,public news_img:string){

    }
}