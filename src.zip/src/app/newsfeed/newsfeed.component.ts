import { Component, OnInit,ViewChild, AfterViewInit } from '@angular/core';
import { News } from './newsfeed-model';
import { NewsfeedDataService } from './newsfeed-data.service';
import { Router } from '@angular/router';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
@Component({
  selector: 'app-newsfeed',
  templateUrl: './newsfeed.component.html',
  styleUrls: ['./newsfeed.component.css']
})
export class NewsfeedComponent implements OnInit, AfterViewInit {
public newsfeed:News[]=[];
public newsfeed1:News[]=[];
public delarr:News[]=[];
dataSource: MatTableDataSource<News>;
displayedColumns = [' ','news_title', 'new_desc','news_img','Action'];
@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatPaginator) paginator: MatPaginator;

constructor(public _data:NewsfeedDataService,public _r:Router) { }

  ngOnInit() {
    this._data.getAllnews().subscribe(
      (data:any)=>{
        this.newsfeed=data;
        this.newsfeed1=data;
        this.dataSource = new MatTableDataSource<News>(this.newsfeed);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      }
    );
  }
  ngAfterViewInit(){

      }
 
  search(item)
  {
    if(item!=''){
    this.newsfeed=this.newsfeed1.filter((x)=>x.news_title.indexOf(item)!==-1)
    }
    else{
      this.newsfeed=this.newsfeed1
    }
  }
onnewsDelete(item){
  if(confirm("Are You Sure want to delete?"))
  {
    this._data.deletenews(item.news_id).subscribe(
      (data:any)=>{
        this.dataSource.data.splice(this.dataSource.data.indexOf(item),1);
        console.log(this.dataSource.data);
        this.dataSource.paginator=this.paginator;
      }
    );
  }
}
  onupdatec(item)
  {
  //  console.log("asd");
    this._r.navigate(["/update-newsfeed",item.news_id]);
  }
  i:number=0;
  checkChange(item:News)
  {
    
      if(this.delarr.find(x=>x==item))
      {
        this.delarr.splice(this.delarr.indexOf(item),1);
      }
      else
      {
        this.delarr.push(item);
      }
      console.log(this.delarr);
    
  }
  deleteAll()
  {
    
    if(confirm("Are You Sure want to delete?"))
    {
    this._data.delteAllnews(this.delarr).subscribe(
      
        (data:any)=>{
          
          for(this.i=0 ; this.i<this.delarr.length ; this.i++)
          {
             

                this.dataSource.data.splice(this.dataSource.data.indexOf(this.delarr[this.i]),1);
                console.log("Complete");
                this.dataSource.paginator=this.paginator;
              
          }
          this.delarr=[];
          
        },
        function(err){console.log(err);},
        function(){

        }
      
    );
  }
  }

  
}
